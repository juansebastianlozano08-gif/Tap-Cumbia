CUMBIA TAP - PROYECTO ANDROID (prototipo 0.1.0)

IMPORTANTE
Este paquete es un proyecto fuente para abrir y compilar en Android Studio.
No contiene un APK compilado porque el entorno donde se preparó no tiene Android SDK/Gradle instalado.

COMO GENERAR EL APK
1. Instala Android Studio en un computador.
2. Descomprime CumbiaTapAndroid.zip.
3. En Android Studio elige Open y selecciona la carpeta CumbiaTapAndroid.
4. Espera a que termine la sincronización de Gradle. Acepta instalar Android SDK Platform 35 si lo solicita.
5. En el menú Build elige Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio generará el APK en:
   app/build/outputs/apk/debug/app-debug.apk
7. Copia ese APK al celular Android, ábrelo y permite instalar aplicaciones desde esa fuente si Android lo solicita.

CONTENIDO DE ESTA VERSION
- Aplicación Android nativa contenedora (WebView).
- Juego arcade táctil de cuatro carriles.
- Puntuación, combo, precisión y ronda de 45 segundos.
- Sonidos sintetizados originales y patrón rítmico de demostración.
- Funciona sin conexión después de instalar.

PENDIENTE PARA LA VERSION DEL MUNDIAL
Esta versión NO contiene todavía los audios ni los punteos originales de la primera temporada.
Para transcribirlos con precisión, se necesitan los videos/audios de cada duelo y verificar los permisos de uso correspondientes.
